<?php

namespace Modules\Addons\Entities;

use Illuminate\Http\Request;
use Nwidart\Modules\Facades\Module as BaseModule;

class Addon extends BaseModule
{
    // To Do
}