### Installation ###

 **1. Configuration repository**
 `composer config repositories.addons-module git https://bitbucket.org/TechVillage/addons-module/src/master.git`

 **2. Run composer require to add the module**
  `composer require TechVillage/addons-module`
