<?php

return [
    'name' => 'CMS',
    'replace_url_one' => 'https:\/\/dashboard.homemaintaining.com',
    'replace_url_two' => 'https://dashboard.homemaintaining.com',
];
