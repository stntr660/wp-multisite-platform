<?php

return [
    'name' => 'Anthropic',
    'ANTHROPIC' => [
        'API_KEY' => env('ANTHROPIC', false)
    ],
];
