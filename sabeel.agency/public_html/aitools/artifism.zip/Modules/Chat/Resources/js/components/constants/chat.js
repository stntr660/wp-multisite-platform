export const CHAT_WITH = {
    CHAT: "chat",
    IMAGE: "Image",
    DOCS: "doc_chat",
    URL: "url",
};