export const LAYOUT = {
    CHAT: "chat",
    IMAGE: "image",
    CONVERSATION: "conversation",
    DOCUMENT: "document",
    WEB: "web",
};
