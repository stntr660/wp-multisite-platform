export const MODEL = {
    STABLE_DIFFUSION: "Stablediffusion",
    OPEN_AI: 'Openai'
};