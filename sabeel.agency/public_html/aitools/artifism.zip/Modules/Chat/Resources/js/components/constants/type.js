export const CHAT_WITH = {
    CHAT: "chat",
    IMAGE: "Image",
    DOCUMENT: "file",
    WEB: "url",
};