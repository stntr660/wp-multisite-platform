<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Anthropic\\Providers\\AnthropicServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Anthropic\\Providers\\AnthropicServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);