<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\OpenAI\\DefaultAiProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\OpenAI\\DefaultAiProvider',
  ),
  'deferred' => 
  array (
  ),
);