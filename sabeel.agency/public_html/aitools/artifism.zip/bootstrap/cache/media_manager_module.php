<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MediaManager\\Providers\\MediaManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MediaManager\\Providers\\MediaManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);