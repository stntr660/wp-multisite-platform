<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PlagiarismCheck\\Providers\\PlagiarismCheckServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PlagiarismCheck\\Providers\\PlagiarismCheckServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);