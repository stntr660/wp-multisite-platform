<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PlagiarismChecker\\Providers\\PlagiarismCheckerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PlagiarismChecker\\Providers\\PlagiarismCheckerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);