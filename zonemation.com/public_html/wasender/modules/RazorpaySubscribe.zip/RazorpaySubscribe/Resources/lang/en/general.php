<?php

return [

    'name'              => 'RazorpaySubscribe',
    'description'       => 'This is my awesome module',

];