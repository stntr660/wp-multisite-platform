<?php

return [

    'name'              => 'PaddlebillingSubscribe',
    'description'       => 'This is my awesome module',

];