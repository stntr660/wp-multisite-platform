<?php


namespace Modules\PaddlebillingSubscribe\Http\Controllers;


class App
{
    public function validate($user)
    {
    }
}