<?php

return [
    'name' => 'PaddlebillingSubscribe',
    'token'=>env('paddle_billing_token',''),
];
