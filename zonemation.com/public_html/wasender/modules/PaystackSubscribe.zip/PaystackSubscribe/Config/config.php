<?php

return [
    'name' => 'PaystackSubscribe',
    'key' =>env('PayStack_SUBSCRIBE_PUBLIC_KEY',''),
    'secret' =>env('PayStack_SUBSCRIBE_SECRET','')
];
