<?php

return [

    'name'              => 'PaystackSubscribe',
    'description'       => 'This is my awesome module',

];