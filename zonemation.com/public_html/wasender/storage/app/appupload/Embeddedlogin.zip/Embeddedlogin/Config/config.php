<?php

return [
    'name' => 'Embeddedlogin',
    'config_id'=>env('EMBEDDED_FB_CONFIG_ID',1),
];
