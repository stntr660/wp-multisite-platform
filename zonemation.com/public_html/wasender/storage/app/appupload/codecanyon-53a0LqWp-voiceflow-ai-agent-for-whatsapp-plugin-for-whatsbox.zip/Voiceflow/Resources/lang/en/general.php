<?php

return [

    'name'              => 'Voiceflow',
    'description'       => 'This is my awesome module',

];